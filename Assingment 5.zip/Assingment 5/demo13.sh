#! /bin/bash

echo "Hidden files in current directory are: "

echo `ls -a | grep "^\."`

