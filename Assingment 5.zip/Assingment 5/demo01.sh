#!/bin/bash
echo "login name:"
whoami
echo "Home Directory:"
~

